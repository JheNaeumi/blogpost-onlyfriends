package com.example.jhenaeumi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogpostOnlyfriendsApplicationTests {

	@Test
	void contextLoads() {
	}

}
