package com.example.jhenaeumi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlogpostOnlyfriendsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlogpostOnlyfriendsApplication.class, args);
	}

}
